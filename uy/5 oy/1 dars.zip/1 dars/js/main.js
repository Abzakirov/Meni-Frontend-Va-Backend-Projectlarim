let myObject = {
  key1: 'Abdullox',
  key2: 'Zokirov',
  key3: 15
};
  

for (let key in myObject) {
  console.log(key + ': ' + myObject[key]);
}