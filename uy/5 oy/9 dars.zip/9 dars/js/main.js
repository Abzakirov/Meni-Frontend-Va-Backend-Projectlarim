const container = document.getElementById('container');

async function fetchData() {
  try {
    const response = await fetch("https://restcountries.com/v3.1/all");
    if (!response.ok) {
      throw new Error("Something went wrong");
    }
    const data = await response.json();
    displayData(data);
  } catch (error) {
    console.error("An error occurred", error);
  }
}

function displayData(data) {
  data.forEach(country => {
    const flag = country.flags.svg;
    const flagAlt = country.flags.alt;
    const population = country.population;
    const name = country.name.common;
    const capital = country.capital[0];
    const region = country.region;

    const countryDiv = document.createElement('div');
    const img = document.createElement('img');
    const countryName = document.createElement('h1');
    const countryRegion = document.createElement('h1');
    const countryCapital = document.createElement('h1');
    const countryPopulation = document.createElement('h1');

    const countryNameSpan = document.createElement('span');
    const countryRegionSpan = document.createElement('span');
    const countryCapitalSpan = document.createElement('span');
    const countryPopulationSpan = document.createElement('span');

    countryNameSpan.textContent = name;
    countryRegionSpan.textContent = region;
    countryCapitalSpan.textContent = capital;
    countryPopulationSpan.textContent = population;

    countryName.textContent = 'Country name: ';
    countryName.append(countryNameSpan);

    countryRegion.textContent = 'Region: ';
    countryRegion.append(countryRegionSpan);

    countryCapital.textContent = 'Capital: ';
    countryCapital.append(countryCapitalSpan);

    countryPopulation.textContent = 'Population: ';
    countryPopulation.append(countryPopulationSpan);

    img.setAttribute("src", flag);
    img.setAttribute("alt", flagAlt);

    countryDiv.append(img, countryName, countryRegion, countryPopulation, countryCapital);
    countryDiv.classList.add("country");
    container.append(countryDiv);
  });
}

fetchData();

const btn = document.getElementById('btn');
const body = document.body;

btn.addEventListener('click', () => {
  body.style.backgroundColor = body.style.backgroundColor === 'black' ? 'white' : 'black';
});