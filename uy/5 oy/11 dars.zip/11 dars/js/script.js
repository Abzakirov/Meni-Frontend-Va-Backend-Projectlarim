кк
var todolist = ['Savol', 'savol2', 'savol3'];


localStorage.setItem('todolist', JSON.stringify(todolist));


var form = document.getElementById('register-form');
var nameInput = document.getElementById('uName');
var passwordInput = document.getElementById('uPw');


function store() {
  localStorage.setItem('username', nameInput.value);
  localStorage.setItem('password', passwordInput.value);
}

form.addEventListener('submit', function(event) {
  event.preventDefault(); 
  store(); 
});
