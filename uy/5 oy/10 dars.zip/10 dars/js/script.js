let container = document.getElementById('container')
fetch("https://restcountries.com/v3.1//all")
    .then(request => {
        if (!request.ok) {
            throw new Error('halovada hatolik mavjud')
        }

        return request.json()
    })
    .then(data => {
        data.forEach(element => {
            console.log(element.name.official);
            let div = document.createElement('div')
            div.innerHTML = `
        <img src="${element.flags.svg}"alt= "">
        <h1>Country name:<span>${element.name.common}</span></h1>
        <h1>Region:<span>${element.region}</span></h1>
        <h1>Capital:<span>${element.capital}</span></h1>
        <h1>Population:<span>${element.population}</span></h1>  
        `
            div.classList.add('country')
            container.append(div)
        });
    })
const btn = document.getElementById('btn');
const body = document.body;

btn.addEventListener('click', () => {
    body.style.backgroundColor = body.style.backgroundColor === 'black' ? 'white' : 'black';
});
let myinput = document.getElementById('myInput')
myinput.addEventListener('keyup', function () {
    container.innerHTML = ""
    let currentCountry = myinput.value
    fetch("https://restcountries.com/v3.1//all")
        .then(request => {
            if (!request.ok) {
                throw new Error('halovada hatolik mavjud')
            }

            return request.json()
        })
        .then(data => {
            data.forEach(element => {
                if (element.name.common.toLowerCase().indexOf(currentCountry.toLowerCase()) == 0) {
                    let div = document.createElement('div')
                    div.innerHTML = `
                <img src="${element.flags.svg}"alt= "">
                <h1>Country name:<span>${element.name.common}</span></h1>
                <h1>Region:<span>${element.region}</span></h1>
                <h1>Capital:<span>${element.capital}</span></h1>
                <h1>Population:<span>${element.population}</span></h1>  
                `
                    div.classList.add('country')
                    container.append(div)
                }
                else if (currentCountry == "") {
                    container.innerHTML = ""
                    let div = document.createElement('div')
                    div.innerHTML = `
                <img src="${element.flags.svg}"alt= "">
                <h1>Country name:<span>${element.name.common}</span></h1>
                <h1>Region:<span>${element.region}</span></h1>
                <h1>Capital:<span>${element.capital}</span></h1>
                <h1>Population:<span>${element.population}</span></h1>  
                `
                    div.classList.add('country')
                    container.append(div)
                }
            })
        })
})