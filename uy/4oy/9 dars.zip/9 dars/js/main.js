
let bar = prompt("1-sonni kiriting");
let bar2 = prompt("2-sonni kiriting");

function kichikKattalik(a, b) {
  if (a < b) {
    alert(a + " kichik  " + b);
  } else if (a > b) {
    alert(a + " katta " + b);
  } else {
    alert(a + " teng " + b);
  }
}

kichikKattalik(bar, bar2);