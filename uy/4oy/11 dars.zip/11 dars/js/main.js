// 1 task
// let soz = "Salom"
// let lovo = "Hayer"
// alert(soz+", "+lovo)
// 2 task
// let raqam = 10
// let raqam2 = 5

// alert(raqam+ ++raqam2)
// 3 task
// let myArray = [];
// myArray.push('element1'); 
// myArray.push('element2'); 
// myArray.push('element3'); 

// alert(myArray.slice(0, -1)); 
// 4 task
// let numbers = [];
// for (let i = 1; i <= 10; i++) {
//   numbers.push(i);
// }

// for (let number of numbers) {
//   alert(number);
// }
// 5 task

// let age = prompt("yoshingzizni kiritig:");

// if (age > 18) {
//   alert("siz balogat yoshinga yetgansiz.");
// } else if (age == 18) {
//   alert(" balogat yoshiz muborak bolsin !");
// } else {
//   alert(" siz balogat yoshinga yetmagansiz.");
// }


// let ism = prompt("ismingizni kiriting :");
// let reversedName = "";

// for (let i = ism.length - 1; i >= 0; i--) {
//   reversedName += ism[i];
// }

// alert(reversedName);