
array.unshift(0); 
array.push(6);
array.shift()
array.pop()
console.log(array);

