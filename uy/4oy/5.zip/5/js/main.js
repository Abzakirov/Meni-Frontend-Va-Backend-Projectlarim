// let son = +prompt("1 son kiriting")
// let san = +prompt("2 son kiriting")
// let 
// let i = 5;
// let result = i++;
// console.log(result);
// console.log(i); 


// let num1 = 10;
// let num2 = 5;

// num1++;
// num2--;

// console.log(num1);
// console.log(num2);


let ra1 = prompt("Введите первое число:");
let ra2= prompt("Введите второе число:");

console.log("Первое число:", ++ra1);
console.log("Второе число:", --ra2);