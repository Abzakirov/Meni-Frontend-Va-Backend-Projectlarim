let example = [];
let firstNumber = prompt("Первое число");
let secondNumber = prompt("Второе число");
example.push(firstNumber);
example.push(secondNumber);
let firstElement = example[3];
let secondElement = example[1];
let answer = firstElement - secondElement;

console.log("Ваш созданный масив " + example);
console.log("Ваш ответ из ходя из чисел " + answer);



