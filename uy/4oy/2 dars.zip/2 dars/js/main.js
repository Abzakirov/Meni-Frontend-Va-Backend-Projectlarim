let desm = prompt("ismingizni kiriting")
let arname = prompt("familiya")
let yosh1 = prompt("yoshingizni kiriting")
let kurs = prompt("qaysi kursda o^qimohchisiz")
let a = confirm("malumotingiz hammasi togrimi")
let random = Math.random()

alert(desm+"\n "+arname+"\n "+yosh1+"\n"+kurs+"\nsizning id raqamiz" +random);

