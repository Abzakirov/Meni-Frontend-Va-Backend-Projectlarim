




 let massiv = [1,2,3,4,5,6,7,8,9,10]
 let rezultat = massiv.map(num=>num*2)
 alert(rezultat)

