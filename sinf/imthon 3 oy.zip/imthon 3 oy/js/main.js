$(document).ready(function () {
    $('.span').click(function (event) {
        $('.span, .first_ul').toggleClass('active');
    })
});